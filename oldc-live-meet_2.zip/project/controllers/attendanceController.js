/**
 * controllers/attendanceController.js
 * -----------------------------------------------------------------------
 * Handles the REST side of attendance: creating a student/session record
 * when a student joins the classroom, and closing it out when they leave
 * (manual leave, browser refresh/close via sendBeacon).
 * -----------------------------------------------------------------------
 */

const { StudentModel, SessionModel, CourseModel, StudentAccountModel, LectureModel, WaitingRoomModel } = require('../models/db');
const bcrypt = require('bcryptjs');
const { UAParser } = require('ua-parser-js');

let ioRef = null;
exports.setIO = (io) => {
  ioRef = io;
};

function getClientIp(req) {
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) return forwarded.split(',')[0].trim();
  return req.socket.remoteAddress || 'Unknown';
}

function parseUserAgent(uaString) {
  const parser = new UAParser(uaString || '');
  const result = parser.getResult();
  const browser = `${result.browser.name || 'Unknown'} ${result.browser.version || ''}`.trim();
  const device = result.device.type
    ? `${result.device.vendor || ''} ${result.device.model || ''} (${result.device.type})`.trim()
    : `Desktop / ${result.os.name || 'Unknown OS'}`;
  return { browser, device };
}

/**
 * POST /api/attendance/join
 * Creates (or reuses) a student record and opens a new attendance session.
 */
exports.joinClass = (req, res) => {
  try {
    const { studentId, fullName, email, course, reason } = req.body;

    if (!studentId || !fullName || !email || !course) {
      return res.status(400).json({ success: false, message: 'All fields are required.' });
    }

    const student = StudentModel.findOrCreate({ studentId, fullName, email, course });

    const { browser, device } = parseUserAgent(req.headers['user-agent']);
    const ipAddress = getClientIp(req);

    const session = SessionModel.create({
      studentDbId: student.id,
      studentName: fullName,
      studentId,
      email,
      course,
      browser,
      device,
      ipAddress,
      reason: reason || 'Manual Join',
    });

    return res.json({ success: true, session, studentDbId: student.id });
  } catch (err) {
    console.error('joinClass error:', err);
    return res.status(500).json({ success: false, message: 'Server error while joining class.' });
  }
};

/**
 * POST /api/attendance/leave
 * Closes an existing session (manual leave or via sendBeacon on unload).
 * Accepts JSON or text/plain (sendBeacon sends a Blob, so we parse manually
 * in server.js middleware if needed).
 */
exports.leaveClass = (req, res) => {
  try {
    const { sessionId, reason } = req.body;
    if (!sessionId) return res.status(400).json({ success: false, message: 'sessionId is required.' });

    const updated = SessionModel.closeSession(sessionId, reason || 'Manual Leave');
    return res.json({ success: true, session: updated });
  } catch (err) {
    console.error('leaveClass error:', err);
    return res.status(500).json({ success: false, message: 'Server error while leaving class.' });
  }
};

/**
 * GET /api/attendance/courses
 */
exports.getCourses = (req, res) => {
  res.json({ success: true, courses: CourseModel.getAll() });
};

// ---------------------------------------------------------------------
// STUDENT ACCOUNT LOGIN (credentials created by a teacher — no self sign-up)
// ---------------------------------------------------------------------
exports.studentLogin = (req, res) => {
  const { username, password } = req.body;
  const account = StudentAccountModel.findByUsername(username);

  if (!account || !bcrypt.compareSync(password || '', account.password_hash)) {
    return res.status(401).json({ success: false, message: 'Invalid username or password.' });
  }

  req.session.isStudent = true;
  req.session.studentAccountId = account.id;
  req.session.studentUsername = account.username;
  res.json({
    success: true,
    account: { id: account.id, username: account.username, fullName: account.full_name, course: account.course },
  });
};

exports.studentLogout = (req, res) => {
  req.session.destroy(() => res.json({ success: true }));
};

exports.studentCheckAuth = (req, res) => {
  if (!req.session.isStudent) return res.json({ success: true, isStudent: false });
  const account = StudentAccountModel.findById(req.session.studentAccountId);
  res.json({
    success: true,
    isStudent: true,
    account: account ? { id: account.id, username: account.username, fullName: account.full_name, course: account.course } : null,
  });
};

exports.requireStudent = (req, res, next) => {
  if (req.session && req.session.isStudent) return next();
  return res.status(401).json({ success: false, message: 'Please log in first.' });
};

/**
 * POST /api/attendance/request-join
 * A logged-in student requests to enter a live lecture. This creates (or
 * reuses) a pending waiting_room row; the teacher must admit/deny it from
 * their live control panel before the student is allowed into the call.
 */
exports.requestJoin = (req, res) => {
  const { roomCode } = req.body;
  if (!roomCode) return res.status(400).json({ success: false, message: 'Room code is required.' });

  const lecture = LectureModel.findByRoomCode(roomCode);
  if (!lecture) return res.status(404).json({ success: false, message: 'No lecture found with that room code.' });
  if (lecture.status !== 'live') {
    return res.status(400).json({ success: false, message: 'This lecture is not live right now.' });
  }

  const waiting = WaitingRoomModel.requestJoin({ lectureId: lecture.id, studentAccountId: req.session.studentAccountId });

  if (ioRef) {
    const account = StudentAccountModel.findById(req.session.studentAccountId);
    ioRef.to(`teacher-lecture:${lecture.room_code}`).emit('waiting-room-update', {
      waitId: waiting.id,
      fullName: account.full_name,
      username: account.username,
      course: account.course,
      requestedAt: waiting.requested_at,
    });
  }

  res.json({ success: true, waitId: waiting.id, roomCode: lecture.room_code, lectureTitle: lecture.title });
};
