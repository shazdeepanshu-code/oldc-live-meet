/**
 * controllers/teacherController.js
 * -----------------------------------------------------------------------
 * Teacher authentication, lecture lifecycle (create/start/end), student
 * account management, and waiting-room admit/deny + live moderation
 * (mute / remove) which pushes real-time events through Socket.IO.
 * -----------------------------------------------------------------------
 */

const bcrypt = require('bcryptjs');
const {
  TeacherModel,
  LectureModel,
  StudentAccountModel,
  WaitingRoomModel,
  SessionModel,
} = require('../models/db');

let ioRef = null;
exports.setIO = (io) => {
  ioRef = io;
};

// ---------------------------------------------------------------------
// AUTH
// ---------------------------------------------------------------------
exports.login = (req, res) => {
  const { username, password } = req.body;
  const teacher = TeacherModel.findByUsername(username);

  if (!teacher || !bcrypt.compareSync(password || '', teacher.password_hash)) {
    return res.status(401).json({ success: false, message: 'Invalid username or password.' });
  }

  req.session.isTeacher = true;
  req.session.teacherId = teacher.id;
  req.session.teacherUsername = teacher.username;
  return res.json({ success: true, teacher: { id: teacher.id, username: teacher.username, fullName: teacher.full_name } });
};

exports.logout = (req, res) => {
  req.session.destroy(() => res.json({ success: true }));
};

exports.checkAuth = (req, res) => {
  res.json({ success: true, isTeacher: !!req.session.isTeacher, username: req.session.teacherUsername || null });
};

exports.requireTeacher = (req, res, next) => {
  if (req.session && req.session.isTeacher) return next();
  return res.status(401).json({ success: false, message: 'Unauthorized. Please log in as teacher.' });
};

// ---------------------------------------------------------------------
// LECTURES
// ---------------------------------------------------------------------
exports.createLecture = (req, res) => {
  const { title } = req.body;
  if (!title || !title.trim()) return res.status(400).json({ success: false, message: 'Lecture title is required.' });

  const lecture = LectureModel.create({ title: title.trim(), teacherId: req.session.teacherId });
  res.json({ success: true, lecture, joinLink: `${req.protocol}://${req.get('host')}/index.html?room=${lecture.room_code}` });
};

exports.getLectures = (req, res) => {
  const lectures = LectureModel.getByTeacher(req.session.teacherId).map((l) => ({
    ...l,
    joinLink: `${req.protocol}://${req.get('host')}/index.html?room=${l.room_code}`,
  }));
  res.json({ success: true, lectures });
};

function ownsLecture(req, lecture) {
  return lecture && lecture.teacher_id === req.session.teacherId;
}

exports.startLecture = (req, res) => {
  const lecture = LectureModel.findById(req.params.id);
  if (!ownsLecture(req, lecture)) return res.status(404).json({ success: false, message: 'Lecture not found.' });

  const updated = LectureModel.start(lecture.id);
  res.json({ success: true, lecture: updated });
};

exports.endLecture = (req, res) => {
  const lecture = LectureModel.findById(req.params.id);
  if (!ownsLecture(req, lecture)) return res.status(404).json({ success: false, message: 'Lecture not found.' });

  const updated = LectureModel.end(lecture.id);
  SessionModel.closeAllForLecture(lecture.id, 'Lecture Ended');

  if (ioRef) ioRef.to(lecture.room_code).emit('lecture-ended');
  res.json({ success: true, lecture: updated });
};

exports.getLectureDetail = (req, res) => {
  const lecture = LectureModel.findById(req.params.id);
  if (!ownsLecture(req, lecture)) return res.status(404).json({ success: false, message: 'Lecture not found.' });

  const waiting = WaitingRoomModel.getPendingForLecture(lecture.id);
  const sessions = SessionModel.getByLecture(lecture.id);
  res.json({
    success: true,
    lecture: { ...lecture, joinLink: `${req.protocol}://${req.get('host')}/index.html?room=${lecture.room_code}` },
    waiting,
    sessions,
  });
};

// ---------------------------------------------------------------------
// STUDENT ACCOUNTS (created by the teacher — no self sign-up)
// ---------------------------------------------------------------------
exports.createStudentAccount = (req, res) => {
  const { username, password, fullName, course } = req.body;
  if (!username || !password || !fullName) {
    return res.status(400).json({ success: false, message: 'Username, password and full name are required.' });
  }
  if (StudentAccountModel.findByUsername(username)) {
    return res.status(409).json({ success: false, message: 'That username is already taken.' });
  }

  const account = StudentAccountModel.create({ username, password, fullName, course, createdBy: req.session.teacherId });
  res.json({ success: true, account });
};

exports.getStudentAccounts = (req, res) => {
  res.json({ success: true, accounts: StudentAccountModel.getByCreator(req.session.teacherId) });
};

// ---------------------------------------------------------------------
// WAITING ROOM — admit / deny
// ---------------------------------------------------------------------
exports.admitStudent = (req, res) => {
  const waitId = Number(req.params.waitId);
  const waiting = WaitingRoomModel.findById(waitId);
  const lecture = waiting && LectureModel.findById(waiting.lecture_id);
  if (!waiting || !ownsLecture(req, lecture)) {
    return res.status(404).json({ success: false, message: 'Request not found.' });
  }

  const account = require('../models/db').StudentAccountModel.findById(waiting.student_account_id);
  const session = SessionModel.create({
    studentDbId: 0,
    studentName: account.full_name,
    studentId: account.username,
    email: '',
    course: account.course,
    reason: 'Admitted by Teacher',
    lectureId: lecture.id,
    studentAccountId: account.id,
  });

  WaitingRoomModel.resolve(waitId, 'admitted', session.id);

  if (ioRef) {
    ioRef.to(`waiting:${lecture.room_code}:${account.id}`).emit('join-approved', {
      sessionId: session.id,
      roomCode: lecture.room_code,
      lectureTitle: lecture.title,
      fullName: account.full_name,
      studentId: account.username,
      course: account.course,
    });
  }

  res.json({ success: true });
};

exports.denyStudent = (req, res) => {
  const waitId = Number(req.params.waitId);
  const waiting = WaitingRoomModel.findById(waitId);
  const lecture = waiting && LectureModel.findById(waiting.lecture_id);
  if (!waiting || !ownsLecture(req, lecture)) {
    return res.status(404).json({ success: false, message: 'Request not found.' });
  }

  const account = require('../models/db').StudentAccountModel.findById(waiting.student_account_id);
  WaitingRoomModel.resolve(waitId, 'denied', null);

  if (ioRef) {
    ioRef.to(`waiting:${lecture.room_code}:${account.id}`).emit('join-denied');
  }

  res.json({ success: true });
};

// ---------------------------------------------------------------------
// LIVE MODERATION — mute / remove a connected participant
// ---------------------------------------------------------------------
exports.muteParticipant = (req, res) => {
  const lecture = LectureModel.findById(req.params.id);
  if (!ownsLecture(req, lecture)) return res.status(404).json({ success: false, message: 'Lecture not found.' });

  if (ioRef) ioRef.to(req.params.socketId).emit('force-mute');
  res.json({ success: true });
};

exports.removeParticipant = (req, res) => {
  const lecture = LectureModel.findById(req.params.id);
  if (!ownsLecture(req, lecture)) return res.status(404).json({ success: false, message: 'Lecture not found.' });

  if (ioRef) ioRef.to(req.params.socketId).emit('force-remove');
  res.json({ success: true });
};
