/**
 * controllers/adminController.js
 * -----------------------------------------------------------------------
 * Admin authentication, dashboard statistics, records querying, CSV/Excel
 * export, and record deletion.
 * -----------------------------------------------------------------------
 */

const bcrypt = require('bcryptjs');
const ExcelJS = require('exceljs');
const { AdminModel, SessionModel, LectureModel } = require('../models/db');

// ---------------------------------------------------------------------
// AUTH
// ---------------------------------------------------------------------
exports.login = (req, res) => {
  const { username, password } = req.body;
  const admin = AdminModel.findByUsername(username);

  if (!admin || !bcrypt.compareSync(password || '', admin.password_hash)) {
    return res.status(401).json({ success: false, message: 'Invalid username or password.' });
  }

  req.session.isAdmin = true;
  req.session.adminUsername = admin.username;
  return res.json({ success: true, message: 'Login successful.' });
};

exports.logout = (req, res) => {
  req.session.destroy(() => {
    res.json({ success: true, message: 'Logged out.' });
  });
};

exports.checkAuth = (req, res) => {
  res.json({ success: true, isAdmin: !!req.session.isAdmin, username: req.session.adminUsername || null });
};

// Middleware to protect admin API routes
exports.requireAdmin = (req, res, next) => {
  if (req.session && req.session.isAdmin) return next();
  return res.status(401).json({ success: false, message: 'Unauthorized. Please log in as admin.' });
};

// ---------------------------------------------------------------------
// DASHBOARD DATA
// ---------------------------------------------------------------------
exports.getStats = (req, res) => {
  res.json({ success: true, stats: SessionModel.getStats() });
};

exports.getLiveLectures = (req, res) => {
  res.json({ success: true, lectures: LectureModel.getAllLive() });
};

exports.getRecords = (req, res) => {
  const { name, studentId, date, course } = req.query;
  const records = SessionModel.getAll({ name, studentId, date, course });
  res.json({ success: true, records });
};

exports.deleteRecord = (req, res) => {
  const { id } = req.params;
  SessionModel.deleteById(id);
  res.json({ success: true, message: 'Record deleted.' });
};

// ---------------------------------------------------------------------
// EXPORTS
// ---------------------------------------------------------------------
function formatDuration(seconds) {
  if (!seconds) return '0 min';
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m} min ${s} sec`;
}

exports.exportCSV = (req, res) => {
  const { name, studentId, date, course } = req.query;
  const records = SessionModel.getAll({ name, studentId, date, course });

  const headers = [
    'Name', 'Student ID', 'Course', 'Email', 'Join Time', 'Leave Time',
    'Duration', 'Reason', 'Browser', 'Device', 'IP Address', 'Date', 'Status',
  ];

  const rows = records.map((r) => [
    r.student_name, r.student_id, r.course, r.email,
    r.join_time, r.leave_time || 'Still Online',
    formatDuration(r.duration_seconds), r.reason, r.browser, r.device,
    r.ip_address, r.date, r.status,
  ]);

  const escapeCell = (cell) => `"${String(cell ?? '').replace(/"/g, '""')}"`;
  const csv = [headers, ...rows].map((row) => row.map(escapeCell).join(',')).join('\n');

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="attendance_records.csv"');
  res.send(csv);
};

exports.exportExcel = async (req, res) => {
  const { name, studentId, date, course } = req.query;
  const records = SessionModel.getAll({ name, studentId, date, course });

  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Attendance');

  sheet.columns = [
    { header: 'Name', key: 'name', width: 20 },
    { header: 'Student ID', key: 'studentId', width: 15 },
    { header: 'Course', key: 'course', width: 20 },
    { header: 'Email', key: 'email', width: 25 },
    { header: 'Join Time', key: 'joinTime', width: 22 },
    { header: 'Leave Time', key: 'leaveTime', width: 22 },
    { header: 'Duration', key: 'duration', width: 15 },
    { header: 'Reason', key: 'reason', width: 18 },
    { header: 'Browser', key: 'browser', width: 18 },
    { header: 'Device', key: 'device', width: 20 },
    { header: 'IP Address', key: 'ip', width: 16 },
    { header: 'Date', key: 'date', width: 14 },
    { header: 'Status', key: 'status', width: 12 },
  ];

  sheet.getRow(1).font = { bold: true };
  sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E5EFF' } };
  sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };

  records.forEach((r) => {
    sheet.addRow({
      name: r.student_name,
      studentId: r.student_id,
      course: r.course,
      email: r.email,
      joinTime: r.join_time,
      leaveTime: r.leave_time || 'Still Online',
      duration: formatDuration(r.duration_seconds),
      reason: r.reason,
      browser: r.browser,
      device: r.device,
      ip: r.ip_address,
      date: r.date,
      status: r.status,
    });
  });

  res.setHeader(
    'Content-Type',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  );
  res.setHeader('Content-Disposition', 'attachment; filename="attendance_records.xlsx"');

  await workbook.xlsx.write(res);
  res.end();
};
