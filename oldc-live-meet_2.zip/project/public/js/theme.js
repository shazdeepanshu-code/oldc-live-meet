/**
 * theme.js — Dark mode toggle, persisted in localStorage.
 */
(function () {
  const root = document.documentElement;
  const saved = localStorage.getItem('classroom-theme');
  if (saved === 'dark') root.setAttribute('data-theme', 'dark');

  function updateIcon() {
    const btn = document.getElementById('themeToggle');
    if (!btn) return;
    btn.textContent = root.getAttribute('data-theme') === 'dark' ? '☀️' : '🌙';
  }

  document.addEventListener('DOMContentLoaded', () => {
    updateIcon();
    const btn = document.getElementById('themeToggle');
    if (btn) {
      btn.addEventListener('click', () => {
        const isDark = root.getAttribute('data-theme') === 'dark';
        if (isDark) {
          root.removeAttribute('data-theme');
          localStorage.setItem('classroom-theme', 'light');
        } else {
          root.setAttribute('data-theme', 'dark');
          localStorage.setItem('classroom-theme', 'dark');
        }
        updateIcon();
      });
    }
  });
})();
