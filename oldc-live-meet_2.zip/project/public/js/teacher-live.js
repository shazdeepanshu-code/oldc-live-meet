/**
 * teacher-live.js
 * -----------------------------------------------------------------------
 * Real-time live control panel for a single lecture:
 *  - Waiting room: admit / deny incoming students
 *  - Live participants: mute / remove connected students
 * -----------------------------------------------------------------------
 */

const urlParams = new URLSearchParams(window.location.search);
const lectureId = urlParams.get('id');

if (!lectureId) window.location.href = 'teacher.html';

let roomCode = null;
let socket = null;

async function init() {
  const res = await fetch(`/api/teacher/lectures/${lectureId}`);
  const data = await res.json();
  if (!data.success) {
    showToast('Lecture not found.', 'error');
    setTimeout(() => (window.location.href = 'teacher.html'), 1500);
    return;
  }

  roomCode = data.lecture.room_code;
  document.getElementById('lectureTitle').textContent = data.lecture.title;
  document.getElementById('lectureRoomCode').textContent = roomCode;
  document.getElementById('goLiveBtn').href = `classroom.html?host=1&room=${roomCode}`;

  renderWaiting(data.waiting);

  socket = io();
  socket.on('connect', () => {
    socket.emit('teacher-watch', { roomCode });
  });

  socket.on('waiting-room-update', (entry) => {
    addWaitingEntry(entry);
    showToast(`${entry.fullName} is waiting to join.`, 'info');
  });

  socket.on('live-participants-update', (roster) => {
    renderLive(roster);
  });
}

// ---------------------------------------------------------------------
// Waiting room
// ---------------------------------------------------------------------
const waitingList = document.getElementById('waitingList');
const waitingCount = document.getElementById('waitingCount');
const waitingEntries = new Map();

function renderWaiting(list) {
  waitingEntries.clear();
  list.forEach((w) => waitingEntries.set(w.id, w));
  redrawWaiting();
}

function addWaitingEntry(entry) {
  waitingEntries.set(entry.waitId, { id: entry.waitId, ...entry });
  redrawWaiting();
}

function redrawWaiting() {
  const arr = Array.from(waitingEntries.values());
  waitingCount.textContent = arr.length;
  waitingList.innerHTML = arr.length
    ? arr
        .map(
          (w) => `
    <div class="participant-row">
      <div>
        <div class="participant-name">${w.fullName || w.full_name}</div>
        <div class="text-muted">${w.username} · ${w.course || 'No course'}</div>
      </div>
      <div class="participant-actions">
        <button class="btn btn-primary btn-sm" onclick="admit(${w.id})">✔ Admit</button>
        <button class="btn btn-danger btn-sm" onclick="deny(${w.id})">✖ Deny</button>
      </div>
    </div>`
        )
        .join('')
    : '<div class="text-muted">No one waiting.</div>';
}

async function admit(waitId) {
  const res = await fetch(`/api/teacher/lectures/${lectureId}/waiting/${waitId}/admit`, { method: 'POST' });
  const data = await res.json();
  if (data.success) {
    waitingEntries.delete(waitId);
    redrawWaiting();
    showToast('Student admitted.', 'success');
  }
}

async function deny(waitId) {
  const res = await fetch(`/api/teacher/lectures/${lectureId}/waiting/${waitId}/deny`, { method: 'POST' });
  const data = await res.json();
  if (data.success) {
    waitingEntries.delete(waitId);
    redrawWaiting();
    showToast('Student denied.', 'info');
  }
}

// ---------------------------------------------------------------------
// Live participants
// ---------------------------------------------------------------------
const liveList = document.getElementById('liveList');
const liveCount = document.getElementById('liveCount');

function renderLive(roster) {
  const students = roster.filter((p) => !p.isObserver);
  liveCount.textContent = students.length;
  liveList.innerHTML = students.length
    ? students
        .map(
          (p) => `
    <div class="participant-row">
      <div>
        <div class="participant-name">${p.fullName || 'Student'} ${p.handRaised ? '✋' : ''}</div>
        <div class="text-muted">${p.course || ''} · ${p.micOn ? '🎙️ Mic on' : '🔇 Muted'} · ${p.cameraOn ? '📷 Cam on' : '📵 Cam off'}</div>
      </div>
      <div class="participant-actions">
        <button class="btn btn-secondary btn-sm" onclick="muteStudent('${p.socketId}')">🔇 Mute</button>
        <button class="btn btn-danger btn-sm" onclick="removeStudent('${p.socketId}')">✖ Remove</button>
      </div>
    </div>`
        )
        .join('')
    : '<div class="text-muted">No one has joined yet.</div>';
}

async function muteStudent(socketId) {
  await fetch(`/api/teacher/lectures/${lectureId}/participants/${socketId}/mute`, { method: 'POST' });
  showToast('Mute request sent.', 'info');
}

async function removeStudent(socketId) {
  if (!confirm('Remove this student from the lecture?')) return;
  await fetch(`/api/teacher/lectures/${lectureId}/participants/${socketId}/remove`, { method: 'POST' });
  showToast('Removal request sent.', 'info');
}

init();
