/**
 * classroom.js
 * -----------------------------------------------------------------------
 * Powers the live video classroom:
 *  - Loads the session created on the join page (redirects home if missing)
 *  - Acquires local camera/mic stream
 *  - Connects to Socket.IO, joins the classroom room
 *  - Establishes a WebRTC mesh (peer connection per participant)
 *  - Renders video tiles + participant sidebar
 *  - Wires up all bottom controls (mic, camera, screen share, raise hand,
 *    fullscreen, leave)
 *  - Reports leave events (manual + refresh/close) to the attendance API
 * -----------------------------------------------------------------------
 */

const ICE_SERVERS = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

// ---------------------------------------------------------------------
// 1. Determine mode: normal student session, admin observer, or teacher
//    broadcast host (all via URL params so classroom.html can serve all three)
// ---------------------------------------------------------------------
const urlParams = new URLSearchParams(window.location.search);
const isObserver = urlParams.get('observer') === '1';
const isHost = urlParams.get('host') === '1';
const observerRoom = urlParams.get('room');

let mySession = {};
if (isObserver) {
  mySession = { fullName: 'Admin (Observer)', roomCode: observerRoom, isObserver: true };
} else if (isHost) {
  mySession = { fullName: 'Teacher', roomCode: observerRoom, isHost: true };
} else {
  const sessionRaw = sessionStorage.getItem('classroomSession');
  if (!sessionRaw) {
    window.location.href = 'index.html';
  }
  mySession = JSON.parse(sessionRaw || '{}');
}

// ---------------------------------------------------------------------
// 2. Global state
// ---------------------------------------------------------------------
let localStream = null;
let screenStream = null;
let micOn = true;
let camOn = true;
let handRaised = false;
let socket = null;

const peerConnections = {}; // socketId -> RTCPeerConnection
const remoteStreams = {}; // socketId -> MediaStream
const participants = {}; // socketId -> { fullName, studentId, course, cameraOn, micOn, handRaised }

const videoGrid = document.getElementById('videoGrid');
const participantList = document.getElementById('participantList');
const participantCountEl = document.getElementById('participantCount');

// ---------------------------------------------------------------------
// 3. Initialize: get media, then connect socket
// ---------------------------------------------------------------------
async function init() {
  if (isObserver) {
    renderObserverBanner();
    connectSocket();
    startClock();
    bindControls();
    return;
  }
  try {
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
  } catch (err) {
    showToast('Camera/Microphone access lost. Returning to home page.', 'error');
    setTimeout(() => (window.location.href = 'index.html'), 2000);
    return;
  }

  renderLocalTile();
  connectSocket();
  startClock();
  bindControls();
}

function renderObserverBanner() {
  const banner = document.createElement('div');
  banner.className = 'tile-label';
  banner.style.cssText = 'padding:10px 16px;background:var(--card-bg,#1e293b);color:var(--text,#fff);text-align:center;';
  banner.textContent = '👁️ You are watching as an Admin observer (view-only, no camera required)';
  videoGrid.parentElement.insertBefore(banner, videoGrid);
}

function initials(name) {
  return (name || '?')
    .split(' ')
    .map((p) => p[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();
}

// ---------------------------------------------------------------------
// 4. Rendering: local + remote video tiles
// ---------------------------------------------------------------------
function renderLocalTile() {
  const tile = document.createElement('div');
  tile.className = 'video-tile local';
  tile.id = 'tile-local';
  tile.innerHTML = `
    <video id="localVideo" autoplay playsinline muted></video>
    <div class="tile-icons">
      <span class="tile-icon-badge muted hidden" id="localMuteBadge">🔇</span>
    </div>
    <div class="tile-label">🙂 ${mySession.fullName} (You)</div>
  `;
  videoGrid.appendChild(tile);
  document.getElementById('localVideo').srcObject = localStream;
}

function ensureRemoteTile(socketId, info) {
  let tile = document.getElementById(`tile-${socketId}`);
  if (!tile) {
    tile = document.createElement('div');
    tile.className = 'video-tile';
    tile.id = `tile-${socketId}`;
    tile.innerHTML = `
      <video id="video-${socketId}" autoplay playsinline></video>
      <div class="avatar-fallback hidden" id="avatar-${socketId}">${initials(info.fullName)}</div>
      <div class="tile-icons">
        <span class="tile-icon-badge muted hidden" id="mute-${socketId}">🔇</span>
        <span class="tile-icon-badge hand hidden" id="hand-${socketId}">✋</span>
      </div>
      <div class="tile-label">${info.fullName || 'Student'}</div>
    `;
    videoGrid.appendChild(tile);
  }
  return tile;
}

function removeRemoteTile(socketId) {
  const tile = document.getElementById(`tile-${socketId}`);
  if (tile) tile.remove();
}

// ---------------------------------------------------------------------
// 5. Sidebar participant list
// ---------------------------------------------------------------------
function renderParticipants() {
  const all = [
    ...(isObserver ? [] : [{ socketId: 'local', fullName: mySession.fullName + ' (You)', course: mySession.course, cameraOn: camOn, micOn: micOn, handRaised }]),
    ...Object.entries(participants).map(([id, p]) => ({ socketId: id, ...p })),
  ];

  participantCountEl.textContent = all.length;
  participantList.innerHTML = all
    .map(
      (p) => `
    <div class="participant-item">
      <div class="participant-avatar">${initials(p.fullName)}</div>
      <div class="participant-info">
        <div class="participant-name">${p.fullName}</div>
        <div class="participant-sub">${p.course || ''}</div>
      </div>
      <div class="participant-icons">
        ${p.handRaised ? '<span>✋</span>' : ''}
        <span>${p.micOn ? '🎙️' : '🔇'}</span>
        <span>${p.cameraOn ? '📷' : '📵'}</span>
      </div>
    </div>`
    )
    .join('');
}

// ---------------------------------------------------------------------
// 6. Socket.IO connection + signaling
// ---------------------------------------------------------------------
function connectSocket() {
  socket = io();

  socket.on('connect', () => {
    setConnectionStatus('connected');
    socket.emit('join-room', {
      sessionId: mySession.sessionId,
      roomCode: mySession.roomCode,
      isObserver: !!isObserver,
      studentInfo: {
        fullName: mySession.fullName,
        studentId: mySession.studentId,
        course: mySession.course,
        email: mySession.email,
        role: isHost ? 'teacher' : 'student',
      },
    });
  });

  socket.on('lecture-ended', () => {
    showToast('The teacher has ended this lecture.', 'warning');
    setTimeout(() => {
      if (isObserver) {
        window.location.href = 'admin.html';
      } else {
        sessionStorage.removeItem('classroomSession');
        cleanupMedia();
        window.location.href = 'index.html';
      }
    }, 1500);
  });

  socket.on('force-mute', () => {
    if (isObserver || !localStream) return;
    micOn = false;
    localStream.getAudioTracks().forEach((t) => (t.enabled = false));
    document.getElementById('micBtn')?.classList.remove('active-toggle');
    document.getElementById('micBtn')?.classList.add('off');
    document.getElementById('localMuteBadge')?.classList.remove('hidden');
    socket.emit('toggle-mic', { on: false });
    showToast('The teacher muted your microphone.', 'warning');
    renderParticipants();
  });

  socket.on('force-remove', () => {
    showToast('You have been removed from this lecture by the teacher.', 'error');
    setTimeout(() => performLeave('Removed by Teacher'), 1200);
  });

  socket.on('disconnect', () => setConnectionStatus('disconnected'));
  socket.io.on('reconnect_attempt', () => setConnectionStatus('reconnecting'));
  socket.io.on('reconnect', () => setConnectionStatus('connected'));

  // Existing participants already in the room -> create outbound offers.
  // STAR TOPOLOGY: a normal student only connects to the TEACHER (not to
  // other students), so connections scale linearly (N) instead of a full
  // mesh (N²). The teacher (host) connects to everyone, since it is the hub.
  socket.on('room-participants', (existing) => {
    existing.forEach((p) => {
      participants[p.socketId] = p;
      const shouldConnect = isHost || p.role === 'teacher';
      if (shouldConnect) {
        ensureRemoteTile(p.socketId, p);
        createPeerConnection(p.socketId, true);
      }
    });
    renderParticipants();
  });

  // A new user joined after us -> wait for their offer (only if we should
  // be connected to them under the star topology rule above).
  socket.on('user-joined', (p) => {
    participants[p.socketId] = p;
    const shouldConnect = isHost || p.role === 'teacher';
    if (shouldConnect) {
      ensureRemoteTile(p.socketId, p);
      createPeerConnection(p.socketId, false);
      showToast(`${p.fullName} joined the class`, 'info');
    }
    renderParticipants();
  });

  socket.on('user-left', ({ socketId, reason }) => {
    const name = participants[socketId]?.fullName || 'A student';
    delete participants[socketId];
    removeRemoteTile(socketId);
    if (peerConnections[socketId]) {
      peerConnections[socketId].close();
      delete peerConnections[socketId];
    }
    renderParticipants();
    showToast(`${name} left the class (${reason})`, 'warning');
  });

  socket.on('participant-count', () => renderParticipants());

  // --- WebRTC signaling ---
  socket.on('webrtc-offer', async ({ from, offer }) => {
    const pc = peerConnections[from] || createPeerConnection(from, false);
    await pc.setRemoteDescription(new RTCSessionDescription(offer));
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    socket.emit('webrtc-answer', { to: from, answer });
  });

  socket.on('webrtc-answer', async ({ from, answer }) => {
    const pc = peerConnections[from];
    if (pc) await pc.setRemoteDescription(new RTCSessionDescription(answer));
  });

  socket.on('webrtc-ice-candidate', async ({ from, candidate }) => {
    const pc = peerConnections[from];
    if (pc && candidate) {
      try {
        await pc.addIceCandidate(new RTCIceCandidate(candidate));
      } catch (e) {
        console.warn('ICE candidate error', e);
      }
    }
  });

  // --- Remote control state updates ---
  socket.on('peer-camera-toggle', ({ socketId, on }) => {
    if (participants[socketId]) participants[socketId].cameraOn = on;
    const avatar = document.getElementById(`avatar-${socketId}`);
    const video = document.getElementById(`video-${socketId}`);
    if (avatar && video) {
      avatar.classList.toggle('hidden', on);
      video.classList.toggle('hidden', !on);
    }
    renderParticipants();
  });

  socket.on('peer-mic-toggle', ({ socketId, on }) => {
    if (participants[socketId]) participants[socketId].micOn = on;
    const badge = document.getElementById(`mute-${socketId}`);
    if (badge) badge.classList.toggle('hidden', on);
    renderParticipants();
  });

  socket.on('peer-raise-hand', ({ socketId, raised, name }) => {
    if (participants[socketId]) participants[socketId].handRaised = raised;
    const badge = document.getElementById(`hand-${socketId}`);
    if (badge) badge.classList.toggle('hidden', !raised);
    if (raised) showToast(`${name} raised their hand ✋`, 'info');
    renderParticipants();
  });
}

function setConnectionStatus(status) {
  const el = document.getElementById('connectionStatus');
  el.className = `connection-status ${status}`;
  const labels = {
    connected: '<span class="dot dot-green"></span> Connected',
    reconnecting: '<span class="dot dot-yellow"></span> Reconnecting...',
    disconnected: '<span class="dot dot-red"></span> Disconnected',
  };
  el.innerHTML = labels[status];
}

// ---------------------------------------------------------------------
// 7. WebRTC peer connection factory
// ---------------------------------------------------------------------
function createPeerConnection(remoteSocketId, isInitiator) {
  if (peerConnections[remoteSocketId]) return peerConnections[remoteSocketId];

  const pc = new RTCPeerConnection(ICE_SERVERS);
  peerConnections[remoteSocketId] = pc;

  if (localStream) {
    localStream.getTracks().forEach((track) => pc.addTrack(track, localStream));
  } else {
    // Observer mode: receive-only, no outgoing media
    pc.addTransceiver('video', { direction: 'recvonly' });
    pc.addTransceiver('audio', { direction: 'recvonly' });
  }

  pc.onicecandidate = (event) => {
    if (event.candidate) {
      socket.emit('webrtc-ice-candidate', { to: remoteSocketId, candidate: event.candidate });
    }
  };

  pc.ontrack = (event) => {
    remoteStreams[remoteSocketId] = event.streams[0];
    const videoEl = document.getElementById(`video-${remoteSocketId}`);
    if (videoEl) videoEl.srcObject = event.streams[0];
  };

  if (isInitiator) {
    pc.onnegotiationneeded = async () => {
      try {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        socket.emit('webrtc-offer', { to: remoteSocketId, offer });
      } catch (err) {
        console.error('Negotiation error', err);
      }
    };
  }

  return pc;
}

// ---------------------------------------------------------------------
// 8. Live clock
// ---------------------------------------------------------------------
function startClock() {
  const clockEl = document.getElementById('liveClock');
  function tick() {
    clockEl.textContent = new Date().toLocaleTimeString();
  }
  tick();
  setInterval(tick, 1000);
}

// ---------------------------------------------------------------------
// 9. Bottom controls
// ---------------------------------------------------------------------
function bindControls() {
  const micBtn = document.getElementById('micBtn');
  const camBtn = document.getElementById('camBtn');
  const screenShareBtn = document.getElementById('screenShareBtn');
  const raiseHandBtn = document.getElementById('raiseHandBtn');
  const fullscreenBtn = document.getElementById('fullscreenBtn');
  const leaveBtn = document.getElementById('leaveBtn');
  const toggleSidebarBtn = document.getElementById('toggleSidebarBtn');
  const sidebar = document.getElementById('sidebar');

  micBtn.addEventListener('click', () => {
    if (!localStream) { showToast('Observers cannot use camera/mic controls.', 'info'); return; }
    micOn = !micOn;
    localStream.getAudioTracks().forEach((t) => (t.enabled = micOn));
    micBtn.classList.toggle('active-toggle', micOn);
    micBtn.classList.toggle('off', !micOn);
    document.getElementById('localMuteBadge').classList.toggle('hidden', micOn);
    socket.emit('toggle-mic', { on: micOn });
    renderParticipants();
  });

  camBtn.addEventListener('click', () => {
    if (!localStream) { showToast('Observers cannot use camera/mic controls.', 'info'); return; }
    camOn = !camOn;
    localStream.getVideoTracks().forEach((t) => (t.enabled = camOn));
    camBtn.classList.toggle('active-toggle', camOn);
    camBtn.classList.toggle('off', !camOn);
    socket.emit('toggle-camera', { on: camOn });
    renderParticipants();
  });

  raiseHandBtn.addEventListener('click', () => {
    handRaised = !handRaised;
    raiseHandBtn.classList.toggle('active-toggle', handRaised);
    socket.emit('raise-hand', { raised: handRaised });
    renderParticipants();
  });

  fullscreenBtn.addEventListener('click', () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen();
    }
  });

  toggleSidebarBtn.addEventListener('click', () => {
    sidebar.classList.toggle('hidden-sidebar');
  });

  screenShareBtn.addEventListener('click', async () => {
    if (!screenStream) {
      try {
        screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        const screenTrack = screenStream.getVideoTracks()[0];

        // Replace outgoing video track on every peer connection
        Object.values(peerConnections).forEach((pc) => {
          const sender = pc.getSenders().find((s) => s.track && s.track.kind === 'video');
          if (sender) sender.replaceTrack(screenTrack);
        });
        document.getElementById('localVideo').srcObject = screenStream;
        screenShareBtn.classList.add('active-toggle');
        socket.emit('screen-share-toggle', { on: true });

        screenTrack.onended = () => stopScreenShare();
      } catch (err) {
        console.warn('Screen share cancelled', err);
      }
    } else {
      stopScreenShare();
    }
  });

  function stopScreenShare() {
    if (!screenStream) return;
    screenStream.getTracks().forEach((t) => t.stop());
    screenStream = null;
    const camTrack = localStream.getVideoTracks()[0];
    Object.values(peerConnections).forEach((pc) => {
      const sender = pc.getSenders().find((s) => s.track && s.track.kind === 'video');
      if (sender && camTrack) sender.replaceTrack(camTrack);
    });
    document.getElementById('localVideo').srcObject = localStream;
    screenShareBtn.classList.remove('active-toggle');
    socket.emit('screen-share-toggle', { on: false });
  }

  // Leave flow
  const leaveModal = document.getElementById('leaveModal');
  leaveBtn.addEventListener('click', () => leaveModal.classList.add('active'));
  document.getElementById('cancelLeaveBtn').addEventListener('click', () => leaveModal.classList.remove('active'));
  document.getElementById('confirmLeaveBtn').addEventListener('click', () => {
    leaveModal.classList.remove('active');
    performLeave('Manual Leave');
  });
}

// ---------------------------------------------------------------------
// 10. Attendance leave reporting
// ---------------------------------------------------------------------
function performLeave(reason) {
  reportLeave(reason);
  if (socket) socket.emit('leave-room');
  sessionStorage.removeItem('classroomSession');
  cleanupMedia();
  window.location.href = 'index.html';
}

function reportLeave(reason) {
  if (!mySession.sessionId) return;
  const payload = JSON.stringify({ sessionId: mySession.sessionId, reason });
  // sendBeacon is the reliable way to fire a request during page unload
  if (navigator.sendBeacon) {
    const blob = new Blob([payload], { type: 'application/json' });
    navigator.sendBeacon('/api/attendance/leave', blob);
  } else {
    fetch('/api/attendance/leave', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: payload,
      keepalive: true,
    });
  }
}

function cleanupMedia() {
  if (localStream) localStream.getTracks().forEach((t) => t.stop());
  if (screenStream) screenStream.getTracks().forEach((t) => t.stop());
  Object.values(peerConnections).forEach((pc) => pc.close());
}

// Fires on refresh, tab close, or navigating away
window.addEventListener('beforeunload', () => {
  reportLeave('Browser Refresh/Close');
});

// Kick everything off
init();
