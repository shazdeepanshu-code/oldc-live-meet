/**
 * join.js
 * -----------------------------------------------------------------------
 * Student flow for OLDC LIVE MEET:
 *  1. Log in with teacher-issued username/password
 *  2. Open the "Join a Live Lecture" modal, grant camera/mic access
 *  3. Enter a room code -> POST /api/attendance/request-join (waiting room)
 *  4. Open a socket and wait for the teacher's admit/deny decision
 *  5. On admit -> redirect into classroom.html
 * -----------------------------------------------------------------------
 */

let localPreviewStream = null;
let currentAccount = null;
let waitSocket = null;

const loginModal = document.getElementById('loginModal');
const openLoginBtn = document.getElementById('openLoginBtn');
const closeLoginModal = document.getElementById('closeLoginModal');
const loginForm = document.getElementById('loginForm');
const loginBtn = document.getElementById('loginBtn');

const joinModal = document.getElementById('joinModal');
const closeModalBtn = document.getElementById('closeModal');
const requestPermissionsBtn = document.getElementById('requestPermissionsBtn');
const permissionError = document.getElementById('permissionError');
const cameraStatus = document.getElementById('cameraStatus');
const micStatus = document.getElementById('micStatus');
const previewVideo = document.getElementById('previewVideo');
const joinForm = document.getElementById('joinForm');
const enterClassBtn = document.getElementById('enterClassBtn');
const roomCodeInput = document.getElementById('roomCode');
const waitingBox = document.getElementById('waitingBox');
const loggedInName = document.getElementById('loggedInName');

// ---------------------------------------------------------------------
// Check existing session on load; prefill room code from ?room= link
// ---------------------------------------------------------------------
const urlParams = new URLSearchParams(window.location.search);
const prefilledRoom = urlParams.get('room');

(async function checkAuth() {
  try {
    const res = await fetch('/api/attendance/check-auth');
    const data = await res.json();
    if (data.success && data.isStudent) {
      currentAccount = data.account;
      if (prefilledRoom) openJoinModal();
    } else if (prefilledRoom) {
      openLoginModal();
    }
  } catch (err) {
    console.error('check-auth failed', err);
  }
})();

// ---------------------------------------------------------------------
// Login modal
// ---------------------------------------------------------------------
openLoginBtn.addEventListener('click', openLoginModal);
closeLoginModal.addEventListener('click', () => loginModal.classList.remove('active'));
loginModal.addEventListener('click', (e) => { if (e.target === loginModal) loginModal.classList.remove('active'); });

function openLoginModal() {
  loginModal.classList.add('active');
}

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('loginUsername').value.trim();
  const password = document.getElementById('loginPassword').value;

  loginBtn.disabled = true;
  loginBtn.textContent = 'Logging in...';

  try {
    const res = await fetch('/api/attendance/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    if (!data.success) {
      showToast(data.message || 'Login failed.', 'error');
      loginBtn.disabled = false;
      loginBtn.textContent = 'Log In →';
      return;
    }
    currentAccount = data.account;
    showToast(`Welcome, ${currentAccount.fullName}!`, 'success');
    loginModal.classList.remove('active');
    loginBtn.disabled = false;
    loginBtn.textContent = 'Log In →';
    openJoinModal();
  } catch (err) {
    console.error('Login error:', err);
    showToast('Server error. Please try again.', 'error');
    loginBtn.disabled = false;
    loginBtn.textContent = 'Log In →';
  }
});

// ---------------------------------------------------------------------
// Join modal
// ---------------------------------------------------------------------
function openJoinModal() {
  loggedInName.textContent = currentAccount ? currentAccount.fullName : '';
  if (prefilledRoom) roomCodeInput.value = prefilledRoom.toUpperCase();
  joinModal.classList.add('active');
}

closeModalBtn.addEventListener('click', closeModal);
joinModal.addEventListener('click', (e) => { if (e.target === joinModal) closeModal(); });

function closeModal() {
  joinModal.classList.remove('active');
  stopPreview();
}

function stopPreview() {
  if (localPreviewStream) {
    localPreviewStream.getTracks().forEach((t) => t.stop());
    localPreviewStream = null;
  }
}

// ---------------------------------------------------------------------
// Camera / Microphone permission request
// ---------------------------------------------------------------------
requestPermissionsBtn.addEventListener('click', async () => {
  permissionError.classList.add('hidden');
  requestPermissionsBtn.disabled = true;
  requestPermissionsBtn.textContent = 'Requesting access...';

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    localPreviewStream = stream;

    cameraStatus.textContent = 'Granted';
    cameraStatus.className = 'permission-status granted';
    micStatus.textContent = 'Granted';
    micStatus.className = 'permission-status granted';

    previewVideo.srcObject = stream;
    previewVideo.classList.remove('hidden');

    requestPermissionsBtn.classList.add('hidden');
    joinForm.classList.remove('hidden');
    enterClassBtn.disabled = false;

    showToast('Camera and microphone access granted!', 'success');
  } catch (err) {
    console.error('Permission error:', err);
    cameraStatus.textContent = 'Denied';
    cameraStatus.className = 'permission-status denied';
    micStatus.textContent = 'Denied';
    micStatus.className = 'permission-status denied';

    permissionError.classList.remove('hidden');
    requestPermissionsBtn.disabled = false;
    requestPermissionsBtn.textContent = 'Try Again';

    showToast('Camera and Microphone access is required to join the classroom.', 'error');
  }
});

// ---------------------------------------------------------------------
// Form submission -> request-join (waiting room) -> wait for admit
// ---------------------------------------------------------------------
joinForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  if (!localPreviewStream) {
    showToast('Camera and Microphone access is required to join the classroom.', 'error');
    return;
  }

  const roomCode = roomCodeInput.value.trim().toUpperCase();
  if (!roomCode) {
    showToast('Please enter a room code.', 'warning');
    return;
  }

  enterClassBtn.disabled = true;
  enterClassBtn.textContent = 'Requesting...';

  try {
    const res = await fetch('/api/attendance/request-join', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ roomCode }),
    });
    const data = await res.json();

    if (!data.success) {
      showToast(data.message || 'Could not join this lecture.', 'error');
      enterClassBtn.disabled = false;
      enterClassBtn.textContent = 'Request to Join →';
      return;
    }

    joinForm.classList.add('hidden');
    waitingBox.classList.remove('hidden');

    waitSocket = io();
    waitSocket.on('connect', () => {
      waitSocket.emit('student-wait', { roomCode: data.roomCode, studentAccountId: currentAccount.id });
    });

    waitSocket.on('join-approved', (info) => {
      sessionStorage.setItem(
        'classroomSession',
        JSON.stringify({
          sessionId: info.sessionId,
          roomCode: info.roomCode,
          fullName: info.fullName,
          studentId: info.studentId,
          course: info.course,
        })
      );
      showToast('You have been admitted! Entering classroom...', 'success');
      stopPreview();
      waitSocket.disconnect();
      window.location.href = 'classroom.html';
    });

    waitSocket.on('join-denied', () => {
      showToast('Your teacher denied entry to this lecture.', 'error');
      waitingBox.classList.add('hidden');
      joinForm.classList.remove('hidden');
      enterClassBtn.disabled = false;
      enterClassBtn.textContent = 'Request to Join →';
      waitSocket.disconnect();
    });
  } catch (err) {
    console.error('Join error:', err);
    showToast('Server error. Please try again.', 'error');
    enterClassBtn.disabled = false;
    enterClassBtn.textContent = 'Request to Join →';
  }
});
