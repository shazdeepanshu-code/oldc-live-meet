/**
 * admin.js
 * -----------------------------------------------------------------------
 * Drives the admin dashboard: session-based login, live stats, searchable
 * / filterable attendance table, CSV/Excel export, and record deletion.
 * -----------------------------------------------------------------------
 */

const loginView = document.getElementById('loginView');
const dashboardView = document.getElementById('dashboardView');
const loginForm = document.getElementById('loginForm');

// ---------------------------------------------------------------------
// Auth check on load
// ---------------------------------------------------------------------
async function checkAuth() {
  try {
    const res = await fetch('/api/admin/check-auth');
    const data = await res.json();
    if (data.isAdmin) {
      showDashboard();
    } else {
      showLogin();
    }
  } catch (err) {
    showLogin();
  }
}

function showLogin() {
  loginView.classList.remove('hidden');
  dashboardView.classList.add('hidden');
}

function showDashboard() {
  loginView.classList.add('hidden');
  dashboardView.classList.remove('hidden');
  loadStats();
  loadCourseFilter();
  loadRecords();
  loadLiveLectures();
  setInterval(loadStats, 10000); // refresh stats every 10s
  setInterval(loadLiveLectures, 8000); // refresh live lectures every 8s
}

// ---------------------------------------------------------------------
// Live Lectures (observer)
// ---------------------------------------------------------------------
async function loadLiveLectures() {
  try {
    const res = await fetch('/api/admin/live-lectures');
    const data = await res.json();
    if (!data.success) return;
    renderLiveLectures(data.lectures);
  } catch (err) {
    console.error('loadLiveLectures failed', err);
  }
}

function renderLiveLectures(lectures) {
  const el = document.getElementById('liveLecturesList');
  if (!lectures.length) {
    el.innerHTML = '<div class="text-muted">No lectures are live right now.</div>';
    return;
  }
  el.innerHTML = lectures
    .map(
      (l) => `
    <div class="participant-row" style="padding:12px 0;border-bottom:1px solid var(--border);">
      <div>
        <div class="participant-name">${l.title}</div>
        <div class="text-muted">Room: ${l.room_code} · Teacher: ${l.teacher_name}</div>
      </div>
      <a class="btn btn-secondary btn-sm" href="classroom.html?observer=1&room=${l.room_code}" target="_blank">👁️ Watch</a>
    </div>`
    )
    .join('');
}

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('loginUsername').value.trim();
  const password = document.getElementById('loginPassword').value;

  try {
    const res = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    if (data.success) {
      showToast('Welcome back, admin!', 'success');
      showDashboard();
    } else {
      showToast(data.message || 'Login failed.', 'error');
    }
  } catch (err) {
    showToast('Server error during login.', 'error');
  }
});

document.getElementById('logoutBtn').addEventListener('click', async () => {
  await fetch('/api/admin/logout', { method: 'POST' });
  showToast('Logged out.', 'info');
  showLogin();
});

// ---------------------------------------------------------------------
// Stats
// ---------------------------------------------------------------------
function formatMinutes(seconds) {
  const m = Math.round((seconds || 0) / 60);
  return `${m}m`;
}

async function loadStats() {
  try {
    const res = await fetch('/api/admin/stats');
    const data = await res.json();
    if (!data.success) return;
    const s = data.stats;
    document.getElementById('statTotalStudents').textContent = s.totalStudents;
    document.getElementById('statOnline').textContent = s.onlineStudents;
    document.getElementById('statOffline').textContent = s.offlineStudents;
    document.getElementById('statTotalAttendance').textContent = s.totalAttendance;
    document.getElementById('statAvgTime').textContent = formatMinutes(s.avgTimeSeconds);
    document.getElementById('statToday').textContent = s.todaysAttendance;
  } catch (err) {
    console.error('loadStats error', err);
  }
}

// ---------------------------------------------------------------------
// Course filter dropdown
// ---------------------------------------------------------------------
async function loadCourseFilter() {
  try {
    const res = await fetch('/api/attendance/courses');
    const data = await res.json();
    const select = document.getElementById('filterCourse');
    if (data.success) {
      data.courses.forEach((c) => {
        const opt = document.createElement('option');
        opt.value = c.name;
        opt.textContent = c.name;
        select.appendChild(opt);
      });
    }
  } catch (err) {
    console.error('loadCourseFilter error', err);
  }
}

// ---------------------------------------------------------------------
// Records table
// ---------------------------------------------------------------------
function getFilters() {
  return {
    name: document.getElementById('filterName').value.trim(),
    studentId: document.getElementById('filterStudentId').value.trim(),
    date: document.getElementById('filterDate').value,
    course: document.getElementById('filterCourse').value,
  };
}

function buildQuery(filters) {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([k, v]) => { if (v) params.append(k, v); });
  return params.toString();
}

function formatDuration(seconds) {
  if (!seconds) return '—';
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}m ${s}s`;
}

async function loadRecords() {
  const query = buildQuery(getFilters());
  try {
    const res = await fetch(`/api/admin/records?${query}`);
    const data = await res.json();
    if (!data.success) return;
    renderTable(data.records);
  } catch (err) {
    console.error('loadRecords error', err);
  }
}

function renderTable(records) {
  const tbody = document.getElementById('recordsTableBody');

  if (!records.length) {
    tbody.innerHTML = `<tr><td colspan="13" class="text-center text-muted" style="padding:30px;">No attendance records found.</td></tr>`;
    return;
  }

  tbody.innerHTML = records
    .map((r) => `
    <tr>
      <td>${r.student_name}</td>
      <td>${r.student_id}</td>
      <td>${r.course}</td>
      <td>${r.email}</td>
      <td>${new Date(r.join_time).toLocaleString()}</td>
      <td>${r.leave_time ? new Date(r.leave_time).toLocaleString() : '—'}</td>
      <td>${formatDuration(r.duration_seconds)}</td>
      <td>${r.reason}</td>
      <td>${r.browser}</td>
      <td>${r.device}</td>
      <td>${r.ip_address}</td>
      <td>
        <span class="badge ${r.status === 'online' ? 'badge-online' : 'badge-offline'}">
          ${r.status === 'online' ? '🟢 Online' : '🔴 Offline'}
        </span>
      </td>
      <td><button class="action-btn" title="Delete record" data-id="${r.id}">🗑️</button></td>
    </tr>`)
    .join('');

  tbody.querySelectorAll('.action-btn').forEach((btn) => {
    btn.addEventListener('click', () => deleteRecord(btn.dataset.id));
  });
}

async function deleteRecord(id) {
  if (!confirm('Delete this attendance record? This cannot be undone.')) return;
  try {
    const res = await fetch(`/api/admin/records/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (data.success) {
      showToast('Record deleted.', 'success');
      loadRecords();
      loadStats();
    }
  } catch (err) {
    showToast('Failed to delete record.', 'error');
  }
}

// ---------------------------------------------------------------------
// Filter buttons + export
// ---------------------------------------------------------------------
document.getElementById('applyFiltersBtn').addEventListener('click', loadRecords);
document.getElementById('resetFiltersBtn').addEventListener('click', () => {
  document.getElementById('filterName').value = '';
  document.getElementById('filterStudentId').value = '';
  document.getElementById('filterDate').value = '';
  document.getElementById('filterCourse').value = '';
  loadRecords();
});

document.getElementById('exportCsvBtn').addEventListener('click', () => {
  const query = buildQuery(getFilters());
  window.location.href = `/api/admin/export/csv?${query}`;
});
document.getElementById('exportExcelBtn').addEventListener('click', () => {
  const query = buildQuery(getFilters());
  window.location.href = `/api/admin/export/excel?${query}`;
});

// Kick off
checkAuth();
