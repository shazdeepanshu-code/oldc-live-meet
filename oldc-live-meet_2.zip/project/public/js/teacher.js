/**
 * teacher.js
 * -----------------------------------------------------------------------
 * Teacher dashboard: login, create/start/end lectures, manage student
 * accounts, and jump into the live control panel for a running lecture.
 * -----------------------------------------------------------------------
 */

const loginScreen = document.getElementById('loginScreen');
const dashboard = document.getElementById('dashboard');
const teacherLoginForm = document.getElementById('teacherLoginForm');
const teacherNameEl = document.getElementById('teacherName');

(async function checkAuth() {
  try {
    const res = await fetch('/api/teacher/check-auth');
    const data = await res.json();
    if (data.success && data.isTeacher) {
      showDashboard(data.username);
    } else {
      loginScreen.classList.remove('hidden');
    }
  } catch (err) {
    loginScreen.classList.remove('hidden');
  }
})();

teacherLoginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;

  try {
    const res = await fetch('/api/teacher/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    if (!data.success) {
      showToast(data.message || 'Login failed.', 'error');
      return;
    }
    showDashboard(data.teacher.username);
    showToast(`Welcome back, ${data.teacher.fullName}!`, 'success');
  } catch (err) {
    showToast('Server error. Please try again.', 'error');
  }
});

function showDashboard(username) {
  loginScreen.classList.add('hidden');
  dashboard.classList.remove('hidden');
  teacherNameEl.textContent = username;
  loadLectures();
}

document.getElementById('logoutBtn').addEventListener('click', async () => {
  await fetch('/api/teacher/logout', { method: 'POST' });
  window.location.reload();
});

// ---------------------------------------------------------------------
// Tabs
// ---------------------------------------------------------------------
document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach((p) => p.classList.add('hidden'));
    btn.classList.add('active');
    document.getElementById(`tab-${btn.dataset.tab}`).classList.remove('hidden');
    if (btn.dataset.tab === 'students') loadStudents();
  });
});

// ---------------------------------------------------------------------
// Lectures
// ---------------------------------------------------------------------
const lecturesList = document.getElementById('lecturesList');

async function loadLectures() {
  const res = await fetch('/api/teacher/lectures');
  const data = await res.json();
  if (!data.success) return;
  renderLectures(data.lectures);
}

function statusBadge(status) {
  const map = { created: ['Not Started', 'badge-gray'], live: ['🔴 LIVE', 'badge-red'], ended: ['Ended', 'badge-gray'] };
  const [label, cls] = map[status] || [status, 'badge-gray'];
  return `<span class="badge ${cls}">${label}</span>`;
}

function renderLectures(lectures) {
  if (!lectures.length) {
    lecturesList.innerHTML = '<div class="card text-muted">No lectures yet. Create your first one above.</div>';
    return;
  }
  lecturesList.innerHTML = lectures
    .map(
      (l) => `
    <div class="card lecture-card">
      <div class="lecture-card-main">
        <h4>${l.title} ${statusBadge(l.status)}</h4>
        <div class="text-muted">Room Code: <strong>${l.room_code}</strong></div>
        <div class="join-link-row">
          <input readonly value="${l.joinLink}" onclick="this.select()" />
          <button class="btn btn-secondary btn-sm" onclick="copyLink('${l.joinLink}')">Copy Link</button>
        </div>
      </div>
      <div class="lecture-card-actions">
        ${l.status === 'created' ? `<button class="btn btn-primary btn-sm" onclick="startLecture(${l.id})">▶ Start Lecture</button>` : ''}
        ${l.status === 'live' ? `<button class="btn btn-danger btn-sm" onclick="endLecture(${l.id})">■ End Lecture</button>
        <a class="btn btn-primary btn-sm" href="teacher-live.html?id=${l.id}">🎛️ Manage Live</a>` : ''}
      </div>
    </div>`
    )
    .join('');
}

function copyLink(link) {
  navigator.clipboard.writeText(link);
  showToast('Join link copied!', 'success');
}

document.getElementById('createLectureForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const title = document.getElementById('lectureTitle').value.trim();
  if (!title) return;

  const res = await fetch('/api/teacher/lectures', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title }),
  });
  const data = await res.json();
  if (!data.success) {
    showToast(data.message || 'Could not create lecture.', 'error');
    return;
  }
  document.getElementById('lectureTitle').value = '';
  showToast('Lecture created!', 'success');
  loadLectures();
});

async function startLecture(id) {
  const res = await fetch(`/api/teacher/lectures/${id}/start`, { method: 'POST' });
  const data = await res.json();
  if (data.success) {
    showToast('Lecture is now LIVE. Share the join link with your students!', 'success');
    loadLectures();
  }
}

async function endLecture(id) {
  if (!confirm('End this lecture? All connected students will be removed.')) return;
  const res = await fetch(`/api/teacher/lectures/${id}/end`, { method: 'POST' });
  const data = await res.json();
  if (data.success) {
    showToast('Lecture ended.', 'info');
    loadLectures();
  }
}

// ---------------------------------------------------------------------
// Students
// ---------------------------------------------------------------------
const studentsTableBody = document.getElementById('studentsTableBody');

async function loadStudents() {
  const res = await fetch('/api/teacher/students');
  const data = await res.json();
  if (!data.success) return;
  studentsTableBody.innerHTML = data.accounts
    .map((a) => `<tr><td>${a.username}</td><td>${a.full_name}</td><td>${a.course || '-'}</td><td>${a.created_at}</td></tr>`)
    .join('') || '<tr><td colspan="4" class="text-muted">No students created yet.</td></tr>';
}

document.getElementById('createStudentForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('stuUsername').value.trim();
  const password = document.getElementById('stuPassword').value;
  const fullName = document.getElementById('stuFullName').value.trim();
  const course = document.getElementById('stuCourse').value.trim();

  const res = await fetch('/api/teacher/students', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password, fullName, course }),
  });
  const data = await res.json();
  if (!data.success) {
    showToast(data.message || 'Could not create student.', 'error');
    return;
  }
  e.target.reset();
  showToast('Student account created!', 'success');
  loadStudents();
});
