/**
 * models/db.js
 * -----------------------------------------------------------------------
 * Central SQLite database module.
 * Uses Node's BUILT-IN "node:sqlite" module (available in Node.js 22.5+,
 * no compilation / native build tools required — this avoids the
 * better-sqlite3 native-compile problem on machines without a C++ toolchain).
 * -----------------------------------------------------------------------
 */

const { DatabaseSync } = require('node:sqlite');
const path = require('path');
const bcrypt = require('bcryptjs');

const DB_PATH = path.join(__dirname, '..', 'database.db');
const db = new DatabaseSync(DB_PATH);

// Better concurrency + durability for a small classroom app
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

// -------------------------------------------------------------------------
// SCHEMA
// -------------------------------------------------------------------------
db.exec(`
  CREATE TABLE IF NOT EXISTS courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL
  );

  CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id TEXT NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    course TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now', 'localtime')),
    UNIQUE(student_id, email)
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_db_id INTEGER NOT NULL,
    socket_id TEXT,
    student_name TEXT NOT NULL,
    student_id TEXT NOT NULL,
    email TEXT NOT NULL,
    course TEXT NOT NULL,
    join_time TEXT NOT NULL,
    leave_time TEXT,
    duration_seconds INTEGER DEFAULT 0,
    reason TEXT DEFAULT 'Manual Join',
    browser TEXT,
    device TEXT,
    ip_address TEXT,
    date TEXT NOT NULL,
    status TEXT DEFAULT 'online',
    FOREIGN KEY (student_db_id) REFERENCES students(id)
  );

  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS teachers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL DEFAULT 'Teacher',
    created_at TEXT DEFAULT (datetime('now', 'localtime'))
  );

  CREATE TABLE IF NOT EXISTS lectures (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    teacher_id INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'created',
    created_at TEXT DEFAULT (datetime('now', 'localtime')),
    started_at TEXT,
    ended_at TEXT,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id)
  );

  CREATE TABLE IF NOT EXISTS student_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    course TEXT,
    created_by INTEGER,
    created_at TEXT DEFAULT (datetime('now', 'localtime'))
  );

  CREATE TABLE IF NOT EXISTS waiting_room (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lecture_id INTEGER NOT NULL,
    student_account_id INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    requested_at TEXT DEFAULT (datetime('now', 'localtime')),
    resolved_at TEXT,
    session_id INTEGER,
    FOREIGN KEY (lecture_id) REFERENCES lectures(id),
    FOREIGN KEY (student_account_id) REFERENCES student_accounts(id)
  );
`);

// Add newer columns to "sessions" if this DB predates them (safe no-op if they exist)
try { db.exec('ALTER TABLE sessions ADD COLUMN lecture_id INTEGER'); } catch (e) {}
try { db.exec('ALTER TABLE sessions ADD COLUMN student_account_id INTEGER'); } catch (e) {}

// -------------------------------------------------------------------------
// SEED DEFAULT DATA (only runs once, safe to call every boot)
// -------------------------------------------------------------------------
function seed() {
  const courseCount = db.prepare('SELECT COUNT(*) AS c FROM courses').get().c;
  if (courseCount === 0) {
    const insertCourse = db.prepare('INSERT INTO courses (name) VALUES (?)');
    ['Computer Science', 'Information Technology', 'Electronics', 'Mechanical Engineering', 'Business Administration']
      .forEach((c) => insertCourse.run(c));
  }

  const adminCount = db.prepare('SELECT COUNT(*) AS c FROM admins').get().c;
  if (adminCount === 0) {
    const hash = bcrypt.hashSync('admin123', 10);
    db.prepare('INSERT INTO admins (username, password_hash) VALUES (?, ?)').run('admin', hash);
    console.log('✔ Default admin created -> username: admin | password: admin123');
  }

  const teacherCount = db.prepare('SELECT COUNT(*) AS c FROM teachers').get().c;
  if (teacherCount === 0) {
    const hash = bcrypt.hashSync('teacher123', 10);
    db.prepare('INSERT INTO teachers (username, password_hash, full_name) VALUES (?, ?, ?)').run('teacher', hash, 'Demo Teacher');
    console.log('✔ Default teacher created -> username: teacher | password: teacher123');
  }
}
seed();

// -------------------------------------------------------------------------
// STUDENT HELPERS
// -------------------------------------------------------------------------
const StudentModel = {
  findOrCreate({ studentId, fullName, email, course }) {
    let student = db
      .prepare('SELECT * FROM students WHERE student_id = ? AND email = ?')
      .get(studentId, email);

    if (!student) {
      const info = db
        .prepare('INSERT INTO students (student_id, full_name, email, course) VALUES (?, ?, ?, ?)')
        .run(studentId, fullName, email, course);
      student = db.prepare('SELECT * FROM students WHERE id = ?').get(info.lastInsertRowid);
    }
    return student;
  },

  getAll() {
    return db.prepare('SELECT * FROM students ORDER BY created_at DESC').all();
  },
};

// -------------------------------------------------------------------------
// SESSION / ATTENDANCE HELPERS
// -------------------------------------------------------------------------
const SessionModel = {
  create({ studentDbId, studentName, studentId, email, course, browser, device, ipAddress, reason, lectureId, studentAccountId }) {
    const now = new Date();
    const info = db
      .prepare(
        `INSERT INTO sessions
        (student_db_id, student_name, student_id, email, course, join_time, reason, browser, device, ip_address, date, status, lecture_id, student_account_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'online', ?, ?)`
      )
      .run(
        studentDbId || 0,
        studentName,
        studentId,
        email || '',
        course || '',
        now.toISOString(),
        reason || 'Manual Join',
        browser || 'Unknown',
        device || 'Unknown',
        ipAddress || 'Unknown',
        now.toISOString().slice(0, 10),
        lectureId || null,
        studentAccountId || null
      );
    return db.prepare('SELECT * FROM sessions WHERE id = ?').get(info.lastInsertRowid);
  },

  getByLecture(lectureId) {
    return db.prepare('SELECT * FROM sessions WHERE lecture_id = ? ORDER BY join_time DESC').all(lectureId);
  },

  closeAllForLecture(lectureId, reason) {
    const openOnes = db.prepare("SELECT id FROM sessions WHERE lecture_id = ? AND status = 'online'").all(lectureId);
    openOnes.forEach((s) => SessionModel.closeSession(s.id, reason));
  },

  attachSocket(sessionId, socketId) {
    db.prepare('UPDATE sessions SET socket_id = ? WHERE id = ?').run(socketId, sessionId);
  },

  findBySocket(socketId) {
    return db.prepare('SELECT * FROM sessions WHERE socket_id = ? AND status = ?').get(socketId, 'online');
  },

  findById(id) {
    return db.prepare('SELECT * FROM sessions WHERE id = ?').get(id);
  },

  closeSession(sessionId, reason) {
    const session = db.prepare('SELECT * FROM sessions WHERE id = ?').get(sessionId);
    if (!session || session.status === 'offline') return null; // already closed

    const leaveTime = new Date();
    const joinTime = new Date(session.join_time);
    const durationSeconds = Math.max(0, Math.round((leaveTime - joinTime) / 1000));

    db.prepare(
      `UPDATE sessions SET leave_time = ?, duration_seconds = ?, reason = ?, status = 'offline' WHERE id = ?`
    ).run(leaveTime.toISOString(), durationSeconds, reason || session.reason, sessionId);

    return db.prepare('SELECT * FROM sessions WHERE id = ?').get(sessionId);
  },

  getAll({ name, studentId, date, course } = {}) {
    let query = 'SELECT * FROM sessions WHERE 1=1';
    const params = [];

    if (name) {
      query += ' AND student_name LIKE ?';
      params.push(`%${name}%`);
    }
    if (studentId) {
      query += ' AND student_id LIKE ?';
      params.push(`%${studentId}%`);
    }
    if (date) {
      query += ' AND date = ?';
      params.push(date);
    }
    if (course) {
      query += ' AND course = ?';
      params.push(course);
    }
    query += ' ORDER BY join_time DESC';
    return db.prepare(query).all(...params);
  },

  getStats() {
    const totalStudents = db.prepare('SELECT COUNT(*) AS c FROM students').get().c;
    const onlineStudents = db.prepare("SELECT COUNT(*) AS c FROM sessions WHERE status = 'online'").get().c;
    const totalAttendance = db.prepare('SELECT COUNT(*) AS c FROM sessions').get().c;
    const today = new Date().toISOString().slice(0, 10);
    const todaysAttendance = db.prepare('SELECT COUNT(*) AS c FROM sessions WHERE date = ?').get(today).c;
    const avgRow = db
      .prepare("SELECT AVG(duration_seconds) AS avg FROM sessions WHERE status = 'offline'")
      .get();
    const avgTimeSeconds = avgRow.avg ? Math.round(avgRow.avg) : 0;

    return {
      totalStudents,
      onlineStudents,
      offlineStudents: Math.max(0, totalStudents - onlineStudents),
      totalAttendance,
      todaysAttendance,
      avgTimeSeconds,
    };
  },

  deleteById(id) {
    return db.prepare('DELETE FROM sessions WHERE id = ?').run(id);
  },

  // Mark every still-online session as offline at server boot (handles crashes)
  clearStaleOnline() {
    db.prepare("UPDATE sessions SET status = 'offline', reason = 'Server Restart', leave_time = datetime('now','localtime') WHERE status = 'online'").run();
  },
};

// -------------------------------------------------------------------------
// COURSE HELPERS
// -------------------------------------------------------------------------
const CourseModel = {
  getAll() {
    return db.prepare('SELECT * FROM courses ORDER BY name ASC').all();
  },
};

// -------------------------------------------------------------------------
// ADMIN HELPERS
// -------------------------------------------------------------------------
const AdminModel = {
  findByUsername(username) {
    return db.prepare('SELECT * FROM admins WHERE username = ?').get(username);
  },
};

// -------------------------------------------------------------------------
// TEACHER HELPERS
// -------------------------------------------------------------------------
const TeacherModel = {
  findByUsername(username) {
    return db.prepare('SELECT * FROM teachers WHERE username = ?').get(username);
  },
  findById(id) {
    return db.prepare('SELECT * FROM teachers WHERE id = ?').get(id);
  },
};

// -------------------------------------------------------------------------
// LECTURE HELPERS
// -------------------------------------------------------------------------
function generateRoomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do {
    code = Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  } while (db.prepare('SELECT id FROM lectures WHERE room_code = ?').get(code));
  return code;
}

const LectureModel = {
  create({ title, teacherId }) {
    const roomCode = generateRoomCode();
    const info = db
      .prepare('INSERT INTO lectures (room_code, title, teacher_id, status) VALUES (?, ?, ?, ?)')
      .run(roomCode, title, teacherId, 'created');
    return db.prepare('SELECT * FROM lectures WHERE id = ?').get(info.lastInsertRowid);
  },

  findById(id) {
    return db.prepare('SELECT * FROM lectures WHERE id = ?').get(id);
  },

  findByRoomCode(roomCode) {
    return db.prepare('SELECT * FROM lectures WHERE room_code = ?').get((roomCode || '').toUpperCase());
  },

  getByTeacher(teacherId) {
    return db.prepare('SELECT * FROM lectures WHERE teacher_id = ? ORDER BY created_at DESC').all(teacherId);
  },

  start(id) {
    db.prepare("UPDATE lectures SET status = 'live', started_at = datetime('now','localtime') WHERE id = ?").run(id);
    return LectureModel.findById(id);
  },

  end(id) {
    db.prepare("UPDATE lectures SET status = 'ended', ended_at = datetime('now','localtime') WHERE id = ?").run(id);
    return LectureModel.findById(id);
  },

  getAllLive() {
    return db
      .prepare(
        `SELECT lectures.*, teachers.full_name AS teacher_name
         FROM lectures JOIN teachers ON teachers.id = lectures.teacher_id
         WHERE lectures.status = 'live' ORDER BY lectures.started_at DESC`
      )
      .all();
  },

  clearStaleLive() {
    db.prepare("UPDATE lectures SET status = 'ended', ended_at = datetime('now','localtime') WHERE status = 'live'").run();
  },
};

// -------------------------------------------------------------------------
// STUDENT ACCOUNT HELPERS (teacher/admin-created login credentials)
// -------------------------------------------------------------------------
const StudentAccountModel = {
  create({ username, password, fullName, course, createdBy }) {
    const hash = bcrypt.hashSync(password, 10);
    const info = db
      .prepare('INSERT INTO student_accounts (username, password_hash, full_name, course, created_by) VALUES (?, ?, ?, ?, ?)')
      .run(username, hash, fullName, course || '', createdBy || null);
    return db.prepare('SELECT id, username, full_name, course, created_at FROM student_accounts WHERE id = ?').get(info.lastInsertRowid);
  },

  findByUsername(username) {
    return db.prepare('SELECT * FROM student_accounts WHERE username = ?').get(username);
  },

  findById(id) {
    return db.prepare('SELECT * FROM student_accounts WHERE id = ?').get(id);
  },

  getByCreator(teacherId) {
    return db
      .prepare('SELECT id, username, full_name, course, created_at FROM student_accounts WHERE created_by = ? ORDER BY created_at DESC')
      .all(teacherId);
  },
};

// -------------------------------------------------------------------------
// WAITING ROOM HELPERS
// -------------------------------------------------------------------------
const WaitingRoomModel = {
  requestJoin({ lectureId, studentAccountId }) {
    const existing = db
      .prepare("SELECT * FROM waiting_room WHERE lecture_id = ? AND student_account_id = ? AND status = 'pending'")
      .get(lectureId, studentAccountId);
    if (existing) return existing;

    const info = db
      .prepare('INSERT INTO waiting_room (lecture_id, student_account_id, status) VALUES (?, ?, ?)')
      .run(lectureId, studentAccountId, 'pending');
    return db.prepare('SELECT * FROM waiting_room WHERE id = ?').get(info.lastInsertRowid);
  },

  findById(id) {
    return db.prepare('SELECT * FROM waiting_room WHERE id = ?').get(id);
  },

  getPendingForLecture(lectureId) {
    return db
      .prepare(
        `SELECT waiting_room.*, student_accounts.full_name, student_accounts.username, student_accounts.course
         FROM waiting_room JOIN student_accounts ON student_accounts.id = waiting_room.student_account_id
         WHERE waiting_room.lecture_id = ? AND waiting_room.status = 'pending'
         ORDER BY waiting_room.requested_at ASC`
      )
      .all(lectureId);
  },

  resolve(id, status, sessionId) {
    db.prepare(
      "UPDATE waiting_room SET status = ?, resolved_at = datetime('now','localtime'), session_id = ? WHERE id = ?"
    ).run(status, sessionId || null, id);
    return WaitingRoomModel.findById(id);
  },
};

module.exports = {
  db,
  StudentModel,
  SessionModel,
  CourseModel,
  AdminModel,
  TeacherModel,
  LectureModel,
  StudentAccountModel,
  WaitingRoomModel,
};
