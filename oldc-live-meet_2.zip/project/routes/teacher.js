/**
 * routes/teacher.js
 * Teacher portal: auth, lecture lifecycle, student accounts, waiting room,
 * and live moderation (mute/remove).
 */
const express = require('express');
const router = express.Router();
const teacherController = require('../controllers/teacherController');

// Auth
router.post('/login', teacherController.login);
router.post('/logout', teacherController.logout);
router.get('/check-auth', teacherController.checkAuth);

// Protected below
const auth = teacherController.requireTeacher;

router.get('/lectures', auth, teacherController.getLectures);
router.post('/lectures', auth, teacherController.createLecture);
router.get('/lectures/:id', auth, teacherController.getLectureDetail);
router.post('/lectures/:id/start', auth, teacherController.startLecture);
router.post('/lectures/:id/end', auth, teacherController.endLecture);

router.get('/students', auth, teacherController.getStudentAccounts);
router.post('/students', auth, teacherController.createStudentAccount);

router.post('/lectures/:id/waiting/:waitId/admit', auth, teacherController.admitStudent);
router.post('/lectures/:id/waiting/:waitId/deny', auth, teacherController.denyStudent);

router.post('/lectures/:id/participants/:socketId/mute', auth, teacherController.muteParticipant);
router.post('/lectures/:id/participants/:socketId/remove', auth, teacherController.removeParticipant);

module.exports = router;
