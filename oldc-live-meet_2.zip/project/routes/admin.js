/**
 * routes/admin.js
 * Admin authentication + dashboard data + export + delete endpoints.
 */
const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');

// Auth
router.post('/login', adminController.login);
router.post('/logout', adminController.logout);
router.get('/check-auth', adminController.checkAuth);

// Protected routes below require an active admin session
router.get('/stats', adminController.requireAdmin, adminController.getStats);
router.get('/live-lectures', adminController.requireAdmin, adminController.getLiveLectures);
router.get('/records', adminController.requireAdmin, adminController.getRecords);
router.delete('/records/:id', adminController.requireAdmin, adminController.deleteRecord);
router.get('/export/csv', adminController.requireAdmin, adminController.exportCSV);
router.get('/export/excel', adminController.requireAdmin, adminController.exportExcel);

module.exports = router;
