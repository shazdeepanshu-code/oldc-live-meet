/**
 * routes/attendance.js
 * Student auth (login only — accounts are teacher-created), request-join
 * (waiting room), leave reporting, and course list.
 */
const express = require('express');
const router = express.Router();
const attendanceController = require('../controllers/attendanceController');

// Student auth
router.post('/login', attendanceController.studentLogin);
router.post('/logout', attendanceController.studentLogout);
router.get('/check-auth', attendanceController.studentCheckAuth);

// Waiting room request (must be logged in)
router.post('/request-join', attendanceController.requireStudent, attendanceController.requestJoin);

// Session lifecycle
router.post('/leave', attendanceController.leaveClass);
router.get('/courses', attendanceController.getCourses);

module.exports = router;
